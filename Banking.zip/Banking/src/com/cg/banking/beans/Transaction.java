package com.cg.banking.beans;

public class Transaction {
	private int transactionID;
	private float amount;
//	private String timeStamp, transactionType, transactionLocation, modeOfTransaction, transactionStatus;
	public Transaction(){}
public Transaction(int transactionID, float amount) {
	super();
	this.transactionID = transactionID;
	this.amount = amount;
}

public int getTransactionID() {
	return transactionID;
}
public void setTransactionID(int transactionID) {
	this.transactionID = transactionID;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}
public Transaction(float amount) {
	super();
	this.amount = amount;
}
@Override
public String toString() {
	return "Transaction [transactionID=" + transactionID + ", amount=" + amount + "]";
}
}
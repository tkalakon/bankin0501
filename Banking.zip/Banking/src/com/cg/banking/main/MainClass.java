package com.cg.banking.main;

import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {

	public static void main(String[] args) {
		try{
			BankingServicesImpl bankingServices=new BankingServicesImpl();
			int customerId1=bankingServices.acceptCustomerDetails("sindhu", "k", "a.com", "rrbb87", "hyd", "telangana", 500090, "ban", "karnataka", 77888);
			System.out.println("customerId1 " +customerId1);
			int customerId2=bankingServices.acceptCustomerDetails("vyuha", "k", "a.com", "rrbb87", "hyd", "telangana", 500090, "ban", "karnataka", 77888);
			System.out.println("customerId2 "+ customerId2);
			long accountNo1=bankingServices.openAccount(100, "savings", 3000);
			System.out.println("account1 for customerId1 "+ accountNo1);
			//		long accountNo2=bankingServices.openAccount(100, "savings", 2000);
			/////	System.out.println("account2 for customerId1 "+accountNo2);
			long accountNo3=bankingServices.openAccount(101, "savings", 1000);
			System.out.println("account1 for customerId2 " +accountNo3);
			int pinNumber=bankingServices.generateNewPin(100,1);
			System.out.println("pin number for customerId1 "+ pinNumber);
			Customer customer	=bankingServices.getCustomerDetails(100);
			System.out.println(customer);

			bankingServices.depositAmount(100, 1, 100000);
//			bankingServices.withdrawAmount(100, 1, 5000,4327 );
//			bankingServices.changeAccountPin(100, 1, 10383, 2455);
			
			Customer customer2	=bankingServices.getCustomerDetails(100);
			System.out.println(customer2);
			Customer customer3	=bankingServices.getCustomerDetails(101);
			System.out.println(customer3);
			bankingServices.closeAccount(101, 2);
			bankingServices.accountStatus(101, 2);
			Customer customer4	=bankingServices.getCustomerDetails(101);
			System.out.println(customer4);

		}
		catch(Exception e){
			System.out.println("exception"+e);
		}
	}


}

















/*Customer customer=new Customer();
	customer.setCustomerID(100);
//	Customer customer2 = new Customer(101,8125858858l,99999999l,"sindhu","kalakonda","a.com","sept 17","eu90922");
	System.out.println(customer.getCustomerID());
//	System.out.println(customer2.getCustomerID());

	Address address=new Address();
	address.setCity("Hyderabad");
	System.out.println(address.getCity());

	Account account =new Account();
	account.setAccountNo(812);
	System.out.println(account.getAccountNo());

	Transaction transaction =new Transaction();
	transaction.setTransactionID(800);
	System.out.println(transaction.getTransactionID());
				}*/